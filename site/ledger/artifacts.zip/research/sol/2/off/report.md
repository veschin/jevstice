# Millcross to Brinehaven: which return tickets to buy?

**Saturday, 15 August: buy Gull Rail. It costs £44, £2 less than Tern Coach.**

- **Gull Rail — £44:** 2 adults × £18 + £8 for the 11-year-old + £0 for the 4-year-old, who travels free with a fare-paying adult. [R1]
- **Tern Coach — £46:** 2 adults × £16 + £7 for the 11-year-old + £7 for the 4-year-old. Both children need a return on August weekends. [C1, C3]

**Wednesday, 19 August: buy Tern Coach. It costs £39, £5 less than Gull Rail.**

- **Gull Rail — £44:** 2 adults × £18 + £8 for the 11-year-old + £0 for the 4-year-old. The same fares and accompanied under-5 rule apply every day. [R1]
- **Tern Coach — £39:** 2 adults × £16 + £7 for the 11-year-old + £0 for the 4-year-old, who travels free with a fare-paying adult on weekdays. [C1, C3]

The summer weekend guide advertises £39 for this family [C2], but the official correction replaces that example for every Saturday and Sunday in August 2026 [C3]. Using £39 for Saturday would make the coach look £5 cheaper than rail when it is actually £2 more expensive.
