# A day at the seaside: Millcross to Brinehaven

These are family totals for standard same-day returns, covering the trip out and back [R1, C1].

| Travel date | Gull Rail [R1] | Tern Coach [C1, C3] | Cheaper choice |
| --- | --- | --- | --- |
| Saturday, 15 August 2026 | 2 × £18 + £8 (age 11) + £0 (age 4) = **£44** | 2 × £16 + £7 (age 11) + £7 (age 4) = **£46** | **Gull Rail by £2** |
| Wednesday, 19 August 2026 | 2 × £18 + £8 (age 11) + £0 (age 4) = **£44** | 2 × £16 + £7 (age 11) + £0 (age 4) = **£39** | **Tern Coach by £5** |

The coach guide’s advertised £39 weekend fare [C2] would make the coach look £5 cheaper on Saturday. Tern Coach’s 1 August correction [C3] supersedes that example: on Saturdays and Sundays in August 2026, the 4-year-old needs a £7 return, bringing the coach total to £46. On Wednesday the 4-year-old travels free with a fare-paying adult under the usual coach rules [C1, C3]. Gull Rail’s accompanied under-5 exemption applies on both days [R1].
