# Millcross to Brinehaven: family day returns

**Saturday 15 August: buy Gull Rail.** It costs **£44** for the family, **£2 less** than Tern Coach at **£46**.

- **Gull Rail:** 2 × £18 for the adults + £8 for the 11-year-old + £0 for the 4-year-old = **£44**. Under-5s travel free with a fare-paying adult every day. [R1]
- **Tern Coach:** 2 × £16 for the adults + £7 for the 11-year-old + £7 for the 4-year-old = **£46**. The August weekend correction requires under-5s to buy a £7 return. [C1, C3]

**Wednesday 19 August: buy Tern Coach.** It costs **£39** for the family, **£5 less** than Gull Rail at **£44**.

- **Gull Rail:** 2 × £18 for the adults + £8 for the 11-year-old + £0 for the 4-year-old = **£44**. [R1]
- **Tern Coach:** 2 × £16 for the adults + £7 for the 11-year-old + £0 for the 4-year-old = **£39**. On weekdays, under-5s still travel free with a fare-paying adult. [C1, C3]

The coach’s July weekend guide advertises **£39** for this family [C2], but the August correction supersedes that example [C3]. Using the old price on Saturday would make the coach look £5 cheaper than rail, when it’s actually £2 more expensive.
