# A day at Brinehaven: which return to buy?

These are family totals for the trip from Millcross to Brinehaven and back on the same day [R1, C1].

| Travel date | Gull Rail | Tern Coach | Cheaper choice |
|---|---|---|---|
| Saturday, 15 August 2026 | 2 × £18 + £8 (age 11) + £0 (age 4) = **£44** [R1] | 2 × £16 + £7 (age 11) + £7 (age 4) = **£46** [C1, C3] | **Gull Rail by £2** |
| Wednesday, 19 August 2026 | 2 × £18 + £8 (age 11) + £0 (age 4) = **£44** [R1] | 2 × £16 + £7 (age 11) + £0 (age 4) = **£39** [C1, C3] | **Tern Coach by £5** |

The 4-year-old travels free with a fare-paying adult on Gull Rail on both days [R1] and on Tern Coach on Wednesday [C1, C3].

The July weekend guide's £39 example would make Tern Coach look cheaper on Saturday [C2]. Tern Coach's 1 August correction supersedes that example: under-5s need a £7 return on August weekends, so the Saturday coach total is £46 [C3].
