# Millcross to Brinehaven: which return tickets to buy

**Saturday, 15 August 2026: Buy Gull Rail returns and save £2.** If you can go on **Wednesday, 19 August 2026**, buy Tern Coach returns and save **£5** compared with rail that day.

These are family totals for standard same-day returns, covering the trip out and back [R1][C1].

| Date | Gull Rail | Tern Coach |
| --- | --- | --- |
| Sat 15 Aug | 2 × £18 adults + £0 (age 4) + £8 (age 11) = **£44** [R1] | 2 × £16 adults + £7 (age 4) + £7 (age 11) = **£46** [C1][C3] |
| Wed 19 Aug | 2 × £18 adults + £0 (age 4) + £8 (age 11) = **£44** [R1] | 2 × £16 adults + £0 (age 4) + £7 (age 11) = **£39** [C1][C3] |

The four-year-old travels free with a fare-paying adult on Gull Rail on both dates and on Tern Coach on Wednesday [R1][C1][C3]. The coach weekend guide advertises £39 for this family [C2], which would make coach look cheaper than rail on Saturday. But Tern Coach's 1 August correction replaces that example: on August weekends the four-year-old needs a £7 return, raising Saturday's coach total to £46 [C3].
