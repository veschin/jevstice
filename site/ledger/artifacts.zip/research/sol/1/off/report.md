# Millcross to Brinehaven: which return tickets to buy?

These totals cover the trip out and back for two adults and two children, aged 4 and 11 ([R1], [C1]).

| Travel day | Gull Rail | Tern Coach | Cheaper choice |
|---|---|---|---|
| Saturday, 15 August 2026 | **£44**: two £18 adults, £0 for the 4-year-old, £8 for the 11-year-old ([R1]) | **£46**: two £16 adults, £7 for each child ([C1], [C3]) | **Gull Rail by £2** |
| Wednesday, 19 August 2026 | **£44**: two £18 adults, £0 for the 4-year-old, £8 for the 11-year-old ([R1]) | **£39**: two £16 adults, £0 for the 4-year-old, £7 for the 11-year-old ([C1], [C3]) | **Tern Coach by £5** |

The 4-year-old travels free with a fare-paying adult on Gull Rail both days ([R1]) and on Tern Coach on Wednesday ([C1], [C3]). Tern Coach’s weekend guide advertises £39 for this family ([C2]), but the later correction supersedes that example: on August Saturdays and Sundays, under-5s need a £7 return too ([C3]). Using the advertised £39 would wrongly make the coach look £5 cheaper on Saturday, when it actually costs £2 more.
