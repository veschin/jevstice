# Day at the seaside: which ticket? (Millcross → Brinehaven)

Party: 2 adults, child aged 4, child aged 11. Standard same-day returns, everyone travels together both ways. Source labels: [R1] Gull Rail fare table, [C1] Tern Coach fare table, [C2] Tern Coach summer weekend guide, [C3] Tern Coach official correction.

## Saturday 15 August 2026

**Gull Rail** [R1]: adults 2 × £18 = £36; the 11-year-old pays a child return £8; the 4-year-old goes **free** with a fare-paying adult. **Total £44.**

**Tern Coach** [C1] as corrected on August weekends by [C3]: adults 2 × £16 = £32; the 11-year-old £7; the 4-year-old must also buy the £7 child return (the under-5 exemption does not apply on August Saturdays). **Total £46.**

**Cheaper: Gull Rail, by £2.**

## Wednesday 19 August 2026

**Gull Rail** [R1]: same fares every day — **Total £44.**

**Tern Coach** [C1], with [C3] confirming the 1 July weekday rules apply Monday–Friday: adults 2 × £16 = £32; the 11-year-old £7; the 4-year-old **free** with a fare-paying adult. **Total £39.**

**Cheaper: Tern Coach, by £5.**

## Watch out: the £39 advert

Tern Coach's summer weekend guide [C2] advertises £39 for exactly this party ("two adults, one child under 5 and one child aged 5–15") on summer weekends. If you used that figure for Saturday, you would wrongly conclude Tern Coach is cheapest (£39 beats £44). But Tern Coach's official correction [C3], issued 1 August 2026, supersedes that £39 family example: on every Saturday and Sunday in August 2026 the under-5 exemption is suspended, so the 4-year-old pays the £7 child return and the party's true Saturday total is £46 — not £39. The correct Saturday answer is Gull Rail at £44. Weekdays are unaffected: [C3] says the 1 July table [C1] still applies Monday to Friday, so £39 is right for Wednesday.

## Bottom line

- **Saturday 15 Aug:** Gull Rail £44 vs Tern Coach £46 → **Gull Rail, saving £2.**
- **Wednesday 19 Aug:** Gull Rail £44 vs Tern Coach £39 → **Tern Coach, saving £5.**

All fares and eligibility rules above are as stated in the supplied sources [R1], [C1], [C2] and [C3]; these operators and fares are fictional.
