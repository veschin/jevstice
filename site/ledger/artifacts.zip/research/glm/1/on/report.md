# Day at the seaside: which ticket?

Family of four — two adults, a child aged 11, a child aged 4 — travelling Millcross ↔ Brinehaven together, one standard same-day return per paying passenger.

## Totals at a glance

| Your day | Gull Rail total | Tern Coach total | Cheaper option |
| --- | --- | --- | --- |
| Saturday 15 August 2026 | **£44** | £46 | **Gull Rail, by £2** |
| Wednesday 19 August 2026 | £44 | **£39** | **Tern Coach, by £5** |

## Where the children's fares go

**Gull Rail, either day** — the same fares apply every day ([R1]):
- 2 adult returns at £18 = £36
- Child aged 11: child return £8 (ages 5 to 15) ([R1])
- Child aged 4: rides free (under 5 with a fare-paying adult) ([R1])
- £36 + £8 + £0 = **£44**

**Tern Coach, Wednesday 19 August** — weekday rules ([C3] keeps the 1 July table in force Monday to Friday):
- 2 adult returns at £16 = £32 ([C1])
- Child aged 11: child return £7 (ages 5 to 15) ([C1])
- Child aged 4: rides free (under 5 with a fare-paying adult) ([C1])
- £32 + £7 + £0 = **£39**

**Tern Coach, Saturday 15 August** — August weekend rule ([C3] on top of [C1]):
- 2 adult returns at £16 = £32 ([C3]: adult fares do not change)
- Child aged 11: child return £7 ([C1], [C3])
- Child aged 4: **child return £7** — [C3] says that for "every Saturday and Sunday in August 2026" the under-5 exemption does not apply and "children under 5 need the £7 child same-day return"
- £32 + £7 + £7 = **£46**

## The advertised £39 — a Saturday trap

Tern Coach's summer weekend guide advertises a party fare of **"£39 on summer weekends"** for exactly this mix: two adults, one child under 5, one child aged 5–15 ([C2]). That price counts the 4-year-old as free, following the 1 July table — which itself says to watch for later operator notices ([C1]).

Tern Coach's 1 August correction replaces the £39 example: on August weekends the under-5 pays the £7 child return ([C3]). Taken at face value, the advert makes Saturday look like coach £39 vs rail £44 — a coach win by £5. With the correction, the Saturday coach fare is £46, so the real winner is the opposite: **Gull Rail by £2**. The £39 stays valid Monday to Friday ([C3]), which is why it matches Wednesday's coach total exactly.

## Bottom line

- **Saturday 15 August:** buy Gull Rail returns — £44 total, £2 cheaper than the coach.
- **Wednesday 19 August:** buy Tern Coach returns — £39 total, £5 cheaper than the rail.

All prices and eligibility rules above come only from the cited notices in your fare packet ([R1], [C1], [C2], [C3]).
