# Day at the seaside: Millcross → Brinehaven returns

Party: 2 adults, one child aged 11, one child aged 4. Everyone travels together out and back on a standard same-day return.

## Quick answer

| Date | Gull Rail total | Tern Coach total | Cheaper choice |
|---|---|---|---|
| Saturday 15 August 2026 | £44 | £46 | **Gull Rail, by £2** |
| Wednesday 19 August 2026 | £44 | £39 | **Tern Coach, by £5** |

## How the children's fares enter each total

**Gull Rail — same price on both days (fares apply every day [R1])**
- Adults: 2 × £18 = £36
- Child aged 11 (aged 5–15 inclusive): £8 child return [R1]
- Child aged 4 (under 5): travels free with a fare-paying adult [R1]
- **Total: £44**

**Tern Coach — Wednesday 19 August (Monday–Friday rules of the 1 July table [C1], confirmed for weekdays by [C3])**
- Adults: 2 × £16 = £32
- Child aged 11: £7 child return [C1]
- Child aged 4: under 5, travels free with a fare-paying adult [C1]
- **Total: £39**

**Tern Coach — Saturday 15 August (August weekend rule [C3])**
- Adults: 2 × £16 = £32 (adult fare unchanged by the correction [C3])
- Child aged 11: £7 child return [C1][C3]
- Child aged 4: on every Saturday and Sunday in August 2026 the under-5 exemption does not apply on this route, so a £7 child same-day return is needed [C3]
- **Total: £46**

## Why the advertised coach price gives the wrong Saturday answer

Tern Coach's summer weekend guide advertises **£39** for exactly this party — two adults, one child under 5 and one aged 5–15 — on summer weekends [C2]. That advert points to the coach as the Saturday bargain. But Tern's official correction of 1 August supersedes that £39 example: in August 2026 weekends the under-5 must buy the £7 child return [C3], which adds £7 and makes the real Saturday coach total £46 — £2 *more* than Gull Rail. The 1 July table itself warns that later operator notices carry exceptions [C1], and this is one. The £39 figure only holds on weekdays, when the 1 July fare and age rules apply [C1][C3].

## Bottom line

- **Saturday 15 August:** buy Gull Rail returns — £44, saving £2 against the coach.
- **Wednesday 19 August:** buy Tern Coach returns — £39, saving £5 against the train.
