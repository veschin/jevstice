# Day at the seaside: Millcross → Brinehaven

**Party:** 2 adults + 2 children (aged 4 and 11). Standard same-day returns, travelling together both ways.

## Quick answer

- **Saturday 15 August 2026 → buy Gull Rail: £44 total** (Tern Coach would cost £46, so Gull Rail is cheaper by £2).
- **Wednesday 19 August 2026 → buy Tern Coach: £39 total** (Gull Rail would cost £44, so Tern Coach is cheaper by £5).

## How each total is built

**The 11-year-old** is in the 5–15 band on both operators and pays a child return every day: £8 on Gull Rail [R1], £7 on Tern Coach [C1].

**The 4-year-old** is under 5, and this is where the two days differ:

- On Gull Rail, a child under 5 travels free with a fare-paying adult, and these fares apply every day [R1]. So the 4-year-old pays nothing on Saturday or Wednesday.
- On Tern Coach, the 1 July table also makes under-5s free [C1], but it points to later operator notices for exceptions [C1]. One such notice, issued 1 August 2026, removes the under-5 exemption on every Saturday and Sunday in August 2026: an under-5 then needs the £7 child same-day return. Monday to Friday, the 1 July rules still apply [C3]. So the 4-year-old rides free on Wednesday but pays £7 on Saturday.

**Saturday 15 August 2026**

| Operator | Calculation | Total |
|---|---|---|
| Gull Rail | 2 × £18 (adults) + £8 (age 11) + £0 (age 4, free) [R1] | **£44** |
| Tern Coach | 2 × £16 (adults) + £7 (age 11) + £7 (age 4, must pay) [C1] [C3] | **£46** |

Cheaper: **Gull Rail, by £2**.

**Wednesday 19 August 2026**

| Operator | Calculation | Total |
|---|---|---|
| Gull Rail | 2 × £18 + £8 + £0 (same fares every day) [R1] | **£44** |
| Tern Coach | 2 × £16 + £7 + £0 (age 4 free, weekday rules apply) [C1] [C3] | **£39** |

Cheaper: **Tern Coach, by £5**.

## Why the advertised coach price can mislead on Saturday

Tern Coach's summer weekend guide advertises "£39 for the party" on summer weekends — and it describes exactly this family: two adults, one child under 5 and one child aged 5–15 [C2]. That makes it very tempting to book the coach for Saturday at £39.

But that guide was published on 5 July, and Tern Coach's official correction of 1 August 2026 explicitly supersedes the £39 family example: on August Saturdays and Sundays the under-5 exemption does not apply and the 4-year-old must pay £7 [C3]. The adults' and 11-year-old's fares are unchanged [C3]. So the true Saturday coach total is £46, not £39 — which is £2 **more** than Gull Rail's £44. A family booking from the advert alone would think the coach saves money on Saturday when it actually costs more.

The £39 figure is only correct for a weekday trip, when the 1 July fare and age rules apply [C3].

## Bottom line

- **Fixed on Saturday 15 August?** Four Gull Rail returns: 2 adult + 1 child (11) + the 4-year-old free = **£44**.
- **Can go Wednesday 19 August?** Four Tern Coach returns: 2 adult + 1 child (11) + the 4-year-old free = **£39**, saving £5 against Gull Rail.
