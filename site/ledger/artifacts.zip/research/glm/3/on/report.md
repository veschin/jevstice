# Day at the seaside: Millcross → Brinehaven

**Who is travelling:** two adults, a child aged 11 and a child aged 4 — one standard same-day return per paying passenger, out and back the same day.

## Saturday 15 August 2026

| Operator | Adults | Child aged 11 | Child aged 4 | Total |
| --- | --- | --- | --- | --- |
| Gull Rail | 2 × £18 = £36 | £8 (ages 5–15) [R1] | free — under 5 with a fare-paying adult [R1] | **£44** |
| Tern Coach | 2 × £16 = £32 | £7 (ages 5–15) [C1] | **£7** — the under-5 exemption is suspended on August Saturdays [C3] | **£46** |

Paying passengers: 3 on Gull Rail, 4 on Tern Coach (the 4-year-old must buy a ticket on the coach).

**Cheaper: Gull Rail, by £2** (£46 − £44).

## Wednesday 19 August 2026

| Operator | Adults | Child aged 11 | Child aged 4 | Total |
| --- | --- | --- | --- | --- |
| Gull Rail | 2 × £18 = £36 | £8 [R1] | free [R1] | **£44** |
| Tern Coach | 2 × £16 = £32 | £7 [C1] | free — the 1 July fare and age rules apply on weekdays [C1] [C3] | **£39** |

Paying passengers: 3 on both operators.

**Cheaper: Tern Coach, by £5** (£44 − £39).

Gull Rail's £44 is the same on both days because its fares "apply every day" [R1].

## How the children's fares enter the sums

- **Aged 11** — inside the 5–15 child band on both operators [R1] [C1], so buys one child same-day return covering both directions: £8 on Gull Rail, £7 on Tern Coach. This child pays on both days.
- **Aged 4** — under 5. On Gull Rail the under-5 travels free with a fare-paying adult, every day [R1]. On Tern Coach that free ride holds Monday to Friday [C1] [C3], but on every August Saturday and Sunday the operator has switched the exemption off and the 4-year-old needs the £7 child same-day return [C3]. That single £7 is the entire difference between the coach's Wednesday and Saturday totals — and it makes the coach the only option where the party pays for four tickets.

## Why the advertised coach price can give the wrong Saturday answer

Tern Coach's summer weekend guide advertises **£39** for exactly this family shape: "two adults, one child under 5 and one child aged 5-15 … £39 on summer weekends" [C2]. That figure simply adds up the 1 July table with the under-5 riding free (2 × £16 + £7) [C1]. It is now out of date: the operator's correction issued 1 August [C3] supersedes the £39 example for every August Saturday and Sunday, and the 1 July coach table itself warns to "See later operator notices for exceptions" [C1].

If you booked Saturday on the advertised £39 you would be **£7 short** (the true total is £46) — and you would reach the wrong verdict, because £39 would make the coach look £5 cheaper than the train, when the train is actually £2 cheaper. The £39 is correct only on the Wednesday.

## Bottom line

- **Saturday 15 August: Gull Rail, £44** — coach £46; the train is cheaper by **£2**.
- **Wednesday 19 August: Tern Coach, £39** — train £44; the coach is cheaper by **£5**.

All fares and eligibility rules come from the supplied packet only: Gull Rail standard fare table, 1 July 2026 [R1]; Tern Coach fare and age table, 1 July 2026 [C1]; Tern Coach summer weekend guide, 5 July 2026 [C2]; Tern Coach official correction, 1 August 2026 [C3].

*(Fictional exercise: operators, route and fares are invented.)*
