# Seaside return fares

For Saturday 15 August, Gull Rail costs **£52**: 2 adults × £18 + the 4-year-old free + the 11-year-old £8, under Gull Rail’s age and fare rules [R1]. Tern Coach costs **£55**: 2 adults × £16 + both children × £7. The 4-year-old must pay the child fare on every August Saturday; the 11-year-old also pays the child fare [C1, C3]. **Gull Rail is cheaper by £3.**

For Wednesday 19 August, Gull Rail remains **£52**: 2 × £18 + free 4-year-old + £8 for the 11-year-old [R1]. Tern Coach costs **£39**: 2 × £16 + free 4-year-old + £7 for the 11-year-old, using the weekday age rules [C1, C3]. **Tern Coach is cheaper by £13.**

The coach guide’s advertised **£39** weekend example may give the wrong Saturday answer: it counts the under-5 as free, but the later correction requires that child to pay £7 on August Saturdays and Sundays, and explicitly supersedes that example [C2, C3].