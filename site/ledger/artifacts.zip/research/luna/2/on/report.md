# Brinehaven day-trip fares

For your two adults and children aged 4 and 11, these are the standard same-day return totals (both directions):

| Date | Gull Rail | Tern Coach | Cheaper option |
|---|---:|---:|---|
| Saturday, 15 August | £44 (£18 × 2 adults + £8 for the 11-year-old + £0 for the 4-year-old) [R1] | £46 (£16 × 2 adults + £7 for each child) [C1, C3] | Gull Rail by £2 |
| Wednesday, 19 August | £44 (£18 × 2 adults + £8 for the 11-year-old + £0 for the 4-year-old) [R1] | £39 (£16 × 2 adults + £7 for the 11-year-old + £0 for the 4-year-old) [C1] | Tern Coach by £5 |

Gull Rail charges £8 for children aged 5–15 and lets an under-5 travel free with a paying adult; those fares apply every day. [R1] Tern Coach's usual table has the same age eligibility and rates of £7 for ages 5–15, with an under-5 free when accompanied by a paying adult. [C1]

The coach guide advertises a £39 family weekend return, but that example is superseded for August Saturdays and Sundays: the 4-year-old needs a £7 child return, while the adult and other child fares stay unchanged. [C2, C3] So the advertised £39 is not the Saturday fare; the corrected Saturday total is £46. On Wednesday, the weekday table rules apply, making the 4-year-old free. [C1, C3]
