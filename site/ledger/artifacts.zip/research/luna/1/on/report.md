# Millcross to Brinehaven: return fares

For two adults, a 4-year-old and an 11-year-old travelling together, the cheaper ticket depends on the day:

| Date | Gull Rail | Tern Coach | Cheaper option |
|---|---:|---:|---|
| Saturday 15 August | £18 × 2 adults + £8 for the 11-year-old + £0 for the accompanied under-5 = **£44** [R1] | £16 × 2 adults + £7 for each child, including the under-5 = **£53** [C1, C3] | **Gull Rail by £9** |
| Wednesday 19 August | £18 × 2 adults + £8 for the 11-year-old + £0 for the accompanied under-5 = **£44** [R1] | £16 × 2 adults + £7 for the 11-year-old + £0 for the accompanied under-5 = **£39** [C1] | **Tern Coach by £5** |

All amounts are same-day return fares covering both directions. Gull Rail charges £8 for children aged 5–15 and lets an accompanied child under 5 travel free every day [R1]. Tern Coach's table has the same age bands and weekday under-5 exemption [C1]. Its August 2026 weekend correction removes that exemption on Saturdays and Sundays: the 4-year-old therefore needs a £7 child return on Saturday [C3].

The coach guide's advertised **£39** family fare could give the wrong Saturday comparison. It is the older example for two adults and two children, but the 1 August correction explicitly supersedes that example for August weekends and requires the under-5 fare on Saturday [C2, C3]. The £39 calculation applies on Wednesday, when the table's under-5 exemption remains in force [C1, C3].