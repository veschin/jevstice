# Millcross–Brinehaven family fares

For two adults, a 4-year-old and an 11-year-old, comparing standard same-day returns:

| Travel day | Gull Rail | Tern Coach | Cheaper option |
|---|---:|---:|---|
| Saturday, 15 August | £18 + £18 + £0 (4-year-old) + £8 (11-year-old) = **£44** | £16 + £16 + £7 (4-year-old) + £7 (11-year-old) = **£46** | **Gull Rail by £2** |
| Wednesday, 19 August | £18 + £18 + £0 (4-year-old) + £8 (11-year-old) = **£44** | £16 + £16 + £0 (4-year-old) + £7 (11-year-old) = **£39** | **Tern Coach by £5** |

Gull Rail's return fares are £18 per adult and £8 for ages 5–15; under-5s travel free with a fare-paying adult, every day ([R1]). Tern Coach's table gives £16 per adult and £7 for ages 5–15, with the same under-5 exemption on weekdays ([C1], [C3]). But on every August Saturday and Sunday, the under-5 must pay the £7 child return fare ([C3]).

The coach guide's advertised £39 family example could give the wrong Saturday answer: it is superseded for August weekends by the correction, so it does not include the 4-year-old's required £7 fare ([C2], [C3]). On Wednesday, the weekday exemption applies, and the £39 calculation is £32 for the adults, £7 for the 11-year-old and £0 for the 4-year-old ([C1], [C3]).