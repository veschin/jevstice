# Millcross to Brinehaven: return fares

For your family of two adults and children aged 4 and 11:

| Travel date | Gull Rail | Tern Coach | Cheaper option |
|---|---:|---:|---|
| Saturday, 15 August | £44 (£18 × 2 adults + £8 for the 11-year-old + £0 for the 4-year-old) | £46 (£16 × 2 adults + £7 for each child) | Gull Rail, by £2 |
| Wednesday, 19 August | £44 (£18 × 2 adults + £8 for the 11-year-old + £0 for the 4-year-old) | £39 (£16 × 2 adults + £7 for the 11-year-old + £0 for the 4-year-old) | Tern Coach, by £5 |

Gull Rail charges £18 per adult return and £8 for children aged 5–15; under-5s travel free with a fare-paying adult (R1). Tern Coach's standard fares are £16 per adult return and £7 for children aged 5–15, with the same accompanied under-5 exemption on weekdays (C1; C3).

The coach guide advertises £39 for this family on summer weekends (C2), but that figure is not the Saturday fare here. The later correction says the under-5 exemption is suspended on every August Saturday and Sunday, so your 4-year-old needs a £7 return; it also supersedes the guide's £39 family example (C3). That makes Saturday's coach total £46, rather than the advertised £39, and makes Gull Rail cheaper.