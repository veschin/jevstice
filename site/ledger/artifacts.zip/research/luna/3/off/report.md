# Millcross–Brinehaven: return fares

For two adults and children aged 4 and 11, each price below covers same-day travel out and back.

| Travel day | Gull Rail | Tern Coach | Cheaper option |
|---|---:|---:|---|
| Saturday 15 August | £18 × 2 + £8 for the 11-year-old + £0 for the 4-year-old = **£44** | £16 × 2 + £7 for each child (including the 4-year-old) = **£46** | **Gull Rail by £2** |
| Wednesday 19 August | £18 × 2 + £8 for the 11-year-old + £0 for the 4-year-old = **£44** | £16 × 2 + £7 for the 11-year-old + £0 for the 4-year-old = **£39** | **Tern Coach by £5** |

Gull Rail charges £18 per adult and £8 for each child aged 5–15; under-5s travel free with a fare-paying adult, every day [R1]. Tern Coach's table gives £16 per adult and £7 for ages 5–15, with the same under-5 exemption on weekdays [C1, C3]. But on every August Saturday and Sunday, Tern requires an under-5 to have the £7 child return [C3].

The advertised £39 coach family example might suggest Tern is cheaper on Saturday. It is not: that example is superseded for August weekends, and the 4-year-old's £7 fare makes the Saturday total £46 [C2, C3].